package routes;

import java.net.URI;

public class EndPoints {
	
	
	/*
	 * FakeStoreApi.com Endpoints
	 */

	public static final String mainURI = "https://fakestoreapi.com";
	
	
	public static final String getAllProducts = "/products";
	public static final String getProductByID = "/products/{id}";
	public static final String GET_PRODUCTS_WITH_LIMIT = "/products?limit={limit}";
	public static final String GET_PRODUCTS_SORTED = "/products?sort={order}";
	public static final String GET_ALL_CATEGORIES = "/products/categories";
	public static final String GET_PRODUCTS_BY_CATEGORY = "/products/category/{category}";
	public static final String CREATE_PRODUCT = "/products";
	public static final String UPDATE_PRODUCT = "/products/{id}";
	public static final String DELETE_PRODUCT = "/products/{id}";
	
	
	

}
