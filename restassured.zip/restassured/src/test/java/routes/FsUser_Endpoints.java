package routes;

public class FsUser_Endpoints {

	public static String MainURI = "https://fakestoreapi.in";
	public static String getAllusers = "/api/users";
	public static String getSingleUser = "/api/users/{id}";
	public static String limiUser = "/api/users?limit={number}";
	public static String pagination = "/api/users?page={number}";
	public static String addUser = "/api/users";
	public static String updateUser = "/api/users/{id}";
	public static String deleteUser = "/api/users/{id}";

}
