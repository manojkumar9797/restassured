package testrun;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		//features = "./features/userNew.feature", tags = "@getAllUser or @getUserById or @getInvalidUserId or @LimitByUsers", glue = "stepdefinitions")
features = "./features/userNew.feature", tags = "@CreateNewUser", glue = "stepdefinitions"
)

//plugin = {"pretty", "html:cucumber-reports/cucumber-pretty.html"}
public class TestRunUsers {

}
