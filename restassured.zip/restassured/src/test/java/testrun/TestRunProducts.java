package testrun;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		//features = "./features", glue = "stepdefinitions", tags = "@GetAllProducts")
		//features = "./features", glue = "stepdefinitions", tags = "@AddProductwithValidEntry")
		//features = "./features", glue = "stepdefinitions", tags = "@AddProductWithMultipleEntry")
		features = "./features", glue = "stepdefinitions", tags = "@DeleteProduct")

public class TestRunProducts {

}
