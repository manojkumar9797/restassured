//package testrun;
//
//import org.testng.annotations.BeforeClass;
//import io.restassured.response.ResponseBody;
//import io.restassured.*;
//import static io.restassured.RestAssured.*;
//import static org.hamcrest.Matchers.*;
//import org.testng.annotations.Test;
//
//import io.restassured.path.json.JsonPath;
//import routes.EndPoints;
//import utils.HelperMethods;
//
//public class ProductsTestRun {
//
//	HelperMethods helperMethods = null;
//
//	@BeforeClass
//	public void initializer() {
//		helperMethods = new HelperMethods();
//	}
//
//	@Test(enabled = false)
//	public void verifyProductSchema() {
//
//		try {
//			helperMethods.validateSchema(EndPoints.mainURI + EndPoints.getAllProducts,
//					".//resources//schemas//product.json");
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	@Test(enabled = false)
//	public void retrieveAllProductsInfo() {
//
//		try {
//			helperMethods = new HelperMethods();
//			ResponseBody repBody = helperMethods.getResponseBody(EndPoints.mainURI + EndPoints.getAllProducts);
//
//			JsonPath jsonPath = new JsonPath(repBody.asString());
//			int totalSize = jsonPath.getInt("size()");
//			System.out.println(totalSize);
//			for (int i = 0; i < totalSize; i++) {
//				System.lineSeparator();
//				System.out.println("ID: " + jsonPath.getInt("[" + i + "].id"));
//				System.out.println("Title: " + jsonPath.getString("[" + i + "].title"));
//				System.out.println("Price: " + jsonPath.getDouble("[" + i + "].price"));
//				System.out.println("Description: " + jsonPath.getString("[" + i + "].description"));
//				System.out.println("Category: " + jsonPath.getString("[" + i + "].category"));
//				System.out.println("ImageLink: " + jsonPath.getString("[" + i + "].image"));
//				System.out.println("Rating:");
//				System.out.print("Rate: " + jsonPath.getDouble("[" + i + "].rating.rate") + ", Total Count: "
//						+ jsonPath.getInt("[" + i + "].rating.count"));
//				System.lineSeparator();
//			}
//
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//
//	}
//
//	@Test(enabled = false)
//	public void check() {
//
//		int newId = given().when().get("https://fakestoreapi.com/products").then().statusCode(200).log().body()
//				.extract().jsonPath().getInt("[0].id");
//
//		System.out.println(newId);
//	}
//	
//	@Test
//	public void checkThree() {
//		helperMethods.getSchema(EndPoints.mainURI + EndPoints.getAllProducts);
//	}
//
//}
