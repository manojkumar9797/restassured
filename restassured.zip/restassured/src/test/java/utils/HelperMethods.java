package utils;

import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.*;
import io.restassured.module.jsv.JsonSchemaValidator;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.naming.directory.SchemaViolationException;

import com.github.fge.jsonschema.main.JsonSchemaFactory;

/**
 * @author mdevaraj {@summary: Resuable methods}
 *
 */
public class HelperMethods {

	public ResponseBody getResponseBody(String url) {

		return given().when().get(url).then().assertThat().statusCode(200).extract().response().body();

	}

	public void validateSchema(String url, String schemaPath) throws IOException {

		String schema = new String(Files.readAllBytes(Paths.get(schemaPath)));
		System.out.println("The Schema: " + schema);

		Response response = given().when().get(url).then().statusCode(200).extract().response();

		response.then().assertThat().body(JsonSchemaValidator.matchesJsonSchema(new File(schemaPath)));

	}

	public void getSchema(String url) {
		
		Response response = RestAssured.get(url);
		String schema = response.asString();
		System.out.println(schema);
	}

}
