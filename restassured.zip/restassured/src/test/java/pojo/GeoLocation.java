package pojo;

public class GeoLocation {
	
    private Double lat;
    private Double longitude; // Renamed to avoid using 'long' keyword
	public Double getLat() {
		return lat;
	}
	public void setLat(Double lat) {
		this.lat = lat;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	public GeoLocation(Double lat, Double longitude) {
		super();
		this.lat = lat;
		this.longitude = longitude;
	}



}
