package pojo;

public class Users {

	private String email;
	private String username;
	private String password;
	private Users_UserName name;
	private Address address;
		
		public Users(String email, String username, String password, Users_UserName name, Address address,
				String phoneNumber) {

			this.email = email;
			this.username = username;
			this.password = password;
			this.name = name;
			this.address = address;
			this.phoneNumber = phoneNumber;
		}

		public Address getAddress() {
			return address;
		}

		public void setAddress(Address address) {
			this.address = address;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		private String phoneNumber;

		public Users_UserName getName() {
			return name;
		}

		public void setName(Users_UserName name) {
			this.name = name;
		}

		// Getter for username
		public String getUsername() {
			return username;
		}

	

		// Setter for username
		public void setUsername(String username) {
			this.username = username;
		}

		// Getter for email
		public String getEmail() {
			return email;
		}

		// Setter for email
		public void setEmail(String email) {
			this.email = email;
		}

		// Getter for password
		public String getPassword() {
			return password;
		}

		// Setter for password
		public void setPassword(String password) {
			this.password = password;
		}

	}


