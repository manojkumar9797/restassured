package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojo.Address;
import pojo.GeoLocation;
import pojo.Users;
import pojo.Users_UserName;
import routes.FsUser_Endpoints;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.Assert;

public class UserStepNew {

	private Response response;
	private int userId;

	@Given("the system has a list of users")
	public void the_system_has_a_list_of_users() {

	}

	@When("a GET request is sent to {string}")
	public void a_get_request_is_sent_to(String string) {

		response = RestAssured.given().baseUri(FsUser_Endpoints.MainURI).when().get(string);

	}

	@Then("the response status code should be {int}")
	public void the_response_status_code_should_be(Integer int1) {
		response.then().statusCode(int1);
	}

	@Then("the response body should contain a list of users")
	public void the_response_body_should_contain_a_list_of_users() {
		response.then().body("size()", notNullValue());
		response.then().log().all();

	}

	/*
	 * Get user by ID
	 */

	@Given("a user with ID {string} exists.")
	public void a_user_with_id_exists(String string) {

		userId = Integer.parseInt(string);

	}

	@When("a GET User By Id request is sent to {string}.")
	public void a_get_user_by_id_request_is_sent_to(String string) {

		response = RestAssured.given().pathParam("id", userId).when().get(FsUser_Endpoints.MainURI + string);

	}

	@Then("the response status code should {int}.")
	public void the_response_status_code_should(Integer int1) {
		response.then().statusCode(equalTo(int1));
	}

	@Then("the response body should contain the user details for ID {string}.")
	public void the_response_body_should_contain_the_user_details_for_id(String string) {

		int id = response.then().extract().jsonPath().getInt("user.id");
		Assert.assertEquals(id, userId);

	}

	/*
	 * get user with InvalidID
	 */

	@Given("no user with ID {string} exists")
	public void no_user_with_id_exists(String string) {
		userId = Integer.parseInt(string);
	}

	@When("a GET new request is sent to {string}")
	public void a_get_new_request_is_sent_to(String string) {
		response = RestAssured.given().pathParam("id", userId).when().get(FsUser_Endpoints.MainURI + string);

	}

	@Then("the response status code should be {int} or {int}")
	public void the_response_status_code_should_be_or(Integer int1, Integer int2) {

		response.then().statusCode(equalTo(int1));
	}

	@Then("the response body should contain an error message indicating user not found")
	public void the_response_body_should_contain_an_error_message_indicating_user_not_found() {
		String statusLine = response.getStatusLine();
		System.out.println(statusLine);
		Assert.assertEquals(statusLine, "HTTP/1.1 404 Not Found");
	}

	/*
	 * Limit By Users
	 */

	@Given("the system has a number of users")
	public void the_system_has_a_number_of_users() {

	}

	@When("a GET request sent to {string} with {string}.")
	public void a_get_request_sent_to_with(String url, String limitId) {
		try {
			response = RestAssured.given().pathParam("limit", limitId).when().get(FsUser_Endpoints.MainURI + url);
			response.then().log().body();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@Then("the response stat-code should be {int}")
	public void the_response_stat_code_should_be(Integer int1) {
		response.then().statusCode(equalTo(int1));
	}

	@Then("the response body should contain {string} users")
	public void the_response_body_should_contain_users(String count) {
		List<Integer> users = response.then().extract().jsonPath().getList("users.id");
		Assert.assertEquals(users.size(), Integer.parseInt(count));
	}

	/*
	 * Create a new user
	 */

	@Given("the system should ready to create a new user.")
	public void the_system_should_ready_to_create_a_new_user() {

	}

	@When("the post request {string} is sent")
	public void the_post_request_is_sent(String url) {

		Users_UserName name = new Users_UserName("ManojKumar", "Devaraj");
		GeoLocation geoLocation = new GeoLocation(100000.222, 100000.222);
		Address address = new Address("Coimbatore", "22 pattu poochi lane", "22", "641001", geoLocation);
		Users users = new Users("manojdeva246@gmail.com", "mano246", "manoj20@", name, address, "89039532");

		response = RestAssured.given().contentType(ContentType.JSON).body(users).when()
				.post(FsUser_Endpoints.MainURI + url);
		
		response.then().log().body();
		
	}

	@Then("It should accept the user details and {int} should returned as success")
	public void it_should_accept_the_user_details_and_should_returned_as_success(Integer int1) {
		int code = response.getStatusCode();
		Assert.assertEquals(code, 200 );
	//	System.out.println(code);
	}

	@Then("the response body should contain the created user data")
	public void the_response_body_should_contain_the_created_user_data() {
		
		String firstname =response.then().extract().jsonPath().getString("user.name.firstname");
		System.out.println(firstname);
		
	}

}
