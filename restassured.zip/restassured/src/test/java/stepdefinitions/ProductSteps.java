package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import pojo.Products;
import routes.EndPoints;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import org.junit.Assert;

public class ProductSteps {
	
	private ResponseBody responseBody = null;
	Response response = null;
	private Products products = null;
	
	/*
	 * Get All Products
	 */

	@Given("User launches the product URL {string}")
	public void user_launches_the_product_url(String GetAllProducts) {
		responseBody =	given()
						.when()
							.get(GetAllProducts)
								.then().assertThat().statusCode(200)
									.body("size()", greaterThan(1)).extract().response().body();
		
	}

	@Then("User should get all the available products")
	public void user_should_get_all_the_available_products() {
		
		JsonPath jsonPath = new JsonPath(responseBody.asString());
		
		System.out.println("The Total Size: " + jsonPath.getInt("size()") );
		
		for (int i = 0; i < jsonPath.getInt("size()"); i++) {
			
			System.out.println();
			System.out.println("ID: " + jsonPath.getInt("[" + i + "].id"));
			System.out.println();
			System.out.println("Title: " + jsonPath.getString("[" + i + "].title"));
			System.out.println("Price: " + jsonPath.getDouble("[" + i + "].price"));
			System.out.println("Description: " + jsonPath.getString("[" + i + "].description"));
			System.out.println("Category: " + jsonPath.getString("[" + i + "].category"));
			System.out.println("ImageLink: " + jsonPath.getString("[" + i + "].image"));
			System.out.print("Rate: " + jsonPath.getDouble("[" + i + "].rating.rate") + ", Total Count: "
					+ jsonPath.getInt("[" + i + "].rating.count"));
			
		}
			
		
		
	}
	
	/*
	 * Add a product with valid data
	 */
	@Given("User Added the product entry {string} URL")
	public void user_added_the_product_entry_url(String AddProduct) {
		
		 products = new Products("Whirlpool Washing Machine",100, "Fully Automatic", "Electronics", "https://whirlpool.com");
		
	 given()
		  .contentType(ContentType.JSON).body(products)
			.when()
				.post(AddProduct).then().assertThat().statusCode(200)
				.body("title", equalTo(products.getTitle())).log().body();
	 

		
	}

	@When("User send the add request with valid details")
	public void user_send_the_add_request_with_valid_details() {
		
	
	}

	@Then("User should get the confirmation message {string}")
	public void user_should_get_the_confirmation_message(String string) {
		
		
	}
	
	/*
	 * Data driven with multiple product data
	 */
	
	@Given("User Added the product entry using the {string} URL, {string}, {string},{string},{string},{string}")       
	public void user_added_the_product_entry_using_the_url(String url, String title, String price, String desc, String category, String image) {
		products = new Products(title, Double.parseDouble(price), desc, category, image);
		
	String retrievedTitle =	given()
			.contentType(ContentType.JSON)
				.body(products)
					.when()
						.post(url)
							.then().assertThat().statusCode(200).log().body().extract().jsonPath().get("title");
	
		System.out.println(retrievedTitle);
	}
	@Then("The user should redirect with {string} Message.")
	public void the_user_should_redirect_with_message(String string) {
	   
	}
	
	
	/*
	 * Delete the products
	 */

	
	@Given("User Delete the product {string} {string}")
	public void user_delete_the_product(String url, String id) {
		given()
				.when()
					.delete(url + id)
						.then().log().body().statusCode(200);
	}
	@Then("User receive the success message")
	public void user_receive_the_success_message() {
		
	 
		
	}
	

}
