package stepdefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.*;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import pojo.Products;
import routes.EndPoints;
import utils.HelperMethods;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import org.junit.Assert;

public class UserSteps {

	private Response response;
	HelperMethods helperMethods = new HelperMethods();

	@When("User send the request {string}")
	public void user_send_the_request(String string) {

		try {
			helperMethods.validateSchema(string, ".//resources//schemas//user.json");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		response = given().when().get(string).then().extract().response();

	}

	@Then("User should get all user accounts")
	public void user_should_get_all_user_accounts() {

		response.then().statusCode(200).and().body("size()", equalTo(10)).log().body();

	}

	@When("user register with Username : {string}, Email:  {string} and Password: {string}")
	public void user_register_with_username_email_and_password(String string, String string2, String string3) {

	}

	@Then("user should redirect with success message {string} or {string}")
	public void user_should_redirect_with_success_message_or(String string, String string2) {

	}

}
