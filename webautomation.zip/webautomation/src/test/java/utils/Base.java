package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Base {

	public static Properties prop = null;
	public static WebDriver driver = null;

	public static String propertiesReader(String key) {

		try {
			InputStream inputStream = new FileInputStream(
			System.getProperty("user.dir") + "//configuration//browser.properties");
			prop = new Properties();
			prop.load(inputStream);
			return prop.getProperty(key);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return null;

	}

	public static WebDriver openBrowser() {

		if (propertiesReader("browser").equals("chrome")) {

			driver = new ChromeDriver();

		} else if (propertiesReader("browser").equals("edge")) {

			driver = new EdgeDriver();
		}

		if (driver != null) {

			driver.manage().window().maximize();
			driver.get(propertiesReader("url"));
			driver.manage().timeouts()
					.implicitlyWait(java.time.Duration.ofSeconds(Integer.parseInt(propertiesReader("iwait"))));
			driver.manage().timeouts()
					.pageLoadTimeout(java.time.Duration.ofSeconds(Integer.parseInt(propertiesReader("pload"))));

		}

		return driver;

	}

}
