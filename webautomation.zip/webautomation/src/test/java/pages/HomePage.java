package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
		super(driver);

	}

	@FindBy(css = ".my-account-text")
	public static WebElement myAccount;
	@FindBy(css = "button[type='button'].login-cta-btn")
	public static WebElement loginButton;
	
	Actions actions = new Actions(driver);
	public void hoverAndClick() {
		actions.moveToElement(myAccount).pause(2000).click(loginButton).perform();

	}

}
